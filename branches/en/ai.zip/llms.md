# org.hisp.dhis.alldevs.demo#1.0.0: DHIS2 Example FHIR Implementation Guide(en)

## Pages

* [Home](index.md)
* [Changes](changes.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [HIV Follow-up Methods](CodeSystem-HIVFollowUpMethods.md)
* [HIV Follow-up Outcomes](CodeSystem-HIVFollowUpOutcomes.md)
* [HIV Follow-up Reasons](CodeSystem-HIVReasonsForFollowUp.md)
* [HIV Entry Points for Facility-Level Testing](CodeSystem-HIVfacilityLevelTestingEntryPoints.md)
* [HIV Reasons for Visit](CodeSystem-HIVreasonsForVisit.md)
* [HIV TPT Regimen](CodeSystem-HIVtptRegimen.md)
* [HIV Treatment Status](CodeSystem-HIVtreatmentStatus.md)
* [HIV Type of Testing](CodeSystem-HIVtypeOfTesting.md)
* [Patient Gender](CodeSystem-patient-gender.md)
* [Patient Sex at Birth](CodeSystem-patient-sex-at-birth.md)

### ValueSets

* [HIV Follow-up Methods Value Set](ValueSet-HIVFollowUpMethodsVS.md)
* [HIV Follow-up Outcome Value Set](ValueSet-HIVFollowUpOutcomesVS.md)
* [Patient Gender Value Set](ValueSet-HIVPatientGenderVS.md)
* [HIV Follow-up Reasons Value Set](ValueSet-HIVReasonsForFollowUpVS.md)
* [HIV Entry Points for Facility-Level Testing Value Set](ValueSet-HIVfacilityLevelTestingEntryPointsVS.md)
* [HIV Reasons for Visit Value Set](ValueSet-HIVreasonsForVisitVS.md)
* [HIV TPT Regimen Value Set](ValueSet-HIVtptRegimenVS.md)
* [HIV Treatment Status Value Set](ValueSet-HIVtreatmentStatusVS.md)
* [HIV Type of Testing Value Set](ValueSet-HIVtypeOfTestingVS.md)
* [Patient Sex at Birth Value Set](ValueSet-patient-sex-at-birth-vs.md)

### Logicals

* [HIV Initial Case Report](StructureDefinition-HIVCaseData.md)
* [HIV Visit](StructureDefinition-HIVCaseVisitData.md)
* [HIV Follow-Up](StructureDefinition-HIVFollowUp.md)
* [HIV Patient Data Model](StructureDefinition-HIVPatientInfo.md)
* [HIV Case Surveillance](StructureDefinition-HIVView.md)
* [Base Patient Data Model](StructureDefinition-PatientInfo.md)
* [DHIS2 Metadata: AttributeValue](StructureDefinition-d2-md-attribute-value.md)
* [DHIS2 Metadata: OptionSet](StructureDefinition-d2-md-option-set.md)
* [DHIS2 Metadata: Option](StructureDefinition-d2-md-option.md)
* [DHIS2 Metadata: OrganisationUnit](StructureDefinition-d2-md-organisation-unit.md)

### Resource Profiles

* [MDOrganisationUnit Location](StructureDefinition-MDOrganisationUnitLocation.md)
* [MDOrganisationUnit Organization](StructureDefinition-MDOrganisationUnitOrganization.md)

### Extensions

* [MDAttributeValue](StructureDefinition-AttributeValue.md)
* [MDOrganisationUnit Hiearchy Level](StructureDefinition-Level.md)
* [MDOrganisationUnitGroup Identifier](StructureDefinition-OrganisationUnitGroup.md)
* [ShortName](StructureDefinition-ShortName.md)

### ImplementationGuides

* [DHIS2 Example FHIR Implementation Guide](ImplementationGuide-org.hisp.dhis.alldevs.demo.md)

### Examples

* [Sierra Leone (Location)](Location-MDOrganisationUnitLocation-Sierra-Leone.md)
* [Sierra Leone (Organization)](Organization-MDOrganisationUnitOrganization-Sierra-Leone.md)
